/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       joshuahimmens                                             */
/*    Created:      Wed Oct 20 2021                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// MotorGroup18         motor_group   18, 19          
// MotorGroup17         motor_group   17, 16          
// ---- END VEXCODE CONFIGURED DEVICES ----

// note that ports 1 and 2 are left
// 3 and 4 are right, order does within groups not matter

#include "vex.h"
#include "cmath"

using namespace vex;


int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  // start config
  MotorGroup18.setStopping(coast);
  MotorGroup17.setStopping(coast);
  while ( true ){
    MotorGroup17.spin(fwd, Controller1.Axis3.position(percent), percent);
    MotorGroup18.spin(fwd, Controller1.Axis2.position(percent), percent);
    wait(5, msec);
  }
}
