#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
controller Controller1 = controller(primary);
motor MotorGroup1MotorA = motor(PORT1, ratio18_1, false);
motor MotorGroup1MotorB = motor(PORT2, ratio18_1, false);
motor_group MotorGroup1 = motor_group(MotorGroup1MotorA, MotorGroup1MotorB);
motor MotorGroup3MotorA = motor(PORT3, ratio18_1, true);
motor MotorGroup3MotorB = motor(PORT4, ratio18_1, true);
motor_group MotorGroup3 = motor_group(MotorGroup3MotorA, MotorGroup3MotorB);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}